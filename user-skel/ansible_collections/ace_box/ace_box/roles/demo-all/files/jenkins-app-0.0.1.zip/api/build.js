var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/@dynatrace/sdk-automation-labs/lib/actions/action-config-types.js
var require_action_config_types = __commonJS({
  "node_modules/@dynatrace/sdk-automation-labs/lib/actions/action-config-types.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
  }
});

// node_modules/lodash/_freeGlobal.js
var require_freeGlobal = __commonJS({
  "node_modules/lodash/_freeGlobal.js"(exports, module) {
    var freeGlobal = typeof global == "object" && global && global.Object === Object && global;
    module.exports = freeGlobal;
  }
});

// node_modules/lodash/_root.js
var require_root = __commonJS({
  "node_modules/lodash/_root.js"(exports, module) {
    var freeGlobal = require_freeGlobal();
    var freeSelf = typeof self == "object" && self && self.Object === Object && self;
    var root = freeGlobal || freeSelf || Function("return this")();
    module.exports = root;
  }
});

// node_modules/lodash/_Symbol.js
var require_Symbol = __commonJS({
  "node_modules/lodash/_Symbol.js"(exports, module) {
    var root = require_root();
    var Symbol2 = root.Symbol;
    module.exports = Symbol2;
  }
});

// node_modules/lodash/_getRawTag.js
var require_getRawTag = __commonJS({
  "node_modules/lodash/_getRawTag.js"(exports, module) {
    var Symbol2 = require_Symbol();
    var objectProto = Object.prototype;
    var hasOwnProperty = objectProto.hasOwnProperty;
    var nativeObjectToString = objectProto.toString;
    var symToStringTag = Symbol2 ? Symbol2.toStringTag : void 0;
    function getRawTag(value) {
      var isOwn = hasOwnProperty.call(value, symToStringTag), tag = value[symToStringTag];
      try {
        value[symToStringTag] = void 0;
        var unmasked = true;
      } catch (e) {
      }
      var result = nativeObjectToString.call(value);
      if (unmasked) {
        if (isOwn) {
          value[symToStringTag] = tag;
        } else {
          delete value[symToStringTag];
        }
      }
      return result;
    }
    module.exports = getRawTag;
  }
});

// node_modules/lodash/_objectToString.js
var require_objectToString = __commonJS({
  "node_modules/lodash/_objectToString.js"(exports, module) {
    var objectProto = Object.prototype;
    var nativeObjectToString = objectProto.toString;
    function objectToString(value) {
      return nativeObjectToString.call(value);
    }
    module.exports = objectToString;
  }
});

// node_modules/lodash/_baseGetTag.js
var require_baseGetTag = __commonJS({
  "node_modules/lodash/_baseGetTag.js"(exports, module) {
    var Symbol2 = require_Symbol();
    var getRawTag = require_getRawTag();
    var objectToString = require_objectToString();
    var nullTag = "[object Null]";
    var undefinedTag = "[object Undefined]";
    var symToStringTag = Symbol2 ? Symbol2.toStringTag : void 0;
    function baseGetTag(value) {
      if (value == null) {
        return value === void 0 ? undefinedTag : nullTag;
      }
      return symToStringTag && symToStringTag in Object(value) ? getRawTag(value) : objectToString(value);
    }
    module.exports = baseGetTag;
  }
});

// node_modules/lodash/isObject.js
var require_isObject = __commonJS({
  "node_modules/lodash/isObject.js"(exports, module) {
    function isObject(value) {
      var type = typeof value;
      return value != null && (type == "object" || type == "function");
    }
    module.exports = isObject;
  }
});

// node_modules/lodash/isFunction.js
var require_isFunction = __commonJS({
  "node_modules/lodash/isFunction.js"(exports, module) {
    var baseGetTag = require_baseGetTag();
    var isObject = require_isObject();
    var asyncTag = "[object AsyncFunction]";
    var funcTag = "[object Function]";
    var genTag = "[object GeneratorFunction]";
    var proxyTag = "[object Proxy]";
    function isFunction(value) {
      if (!isObject(value)) {
        return false;
      }
      var tag = baseGetTag(value);
      return tag == funcTag || tag == genTag || tag == asyncTag || tag == proxyTag;
    }
    module.exports = isFunction;
  }
});

// node_modules/lodash/_coreJsData.js
var require_coreJsData = __commonJS({
  "node_modules/lodash/_coreJsData.js"(exports, module) {
    var root = require_root();
    var coreJsData = root["__core-js_shared__"];
    module.exports = coreJsData;
  }
});

// node_modules/lodash/_isMasked.js
var require_isMasked = __commonJS({
  "node_modules/lodash/_isMasked.js"(exports, module) {
    var coreJsData = require_coreJsData();
    var maskSrcKey = function() {
      var uid = /[^.]+$/.exec(coreJsData && coreJsData.keys && coreJsData.keys.IE_PROTO || "");
      return uid ? "Symbol(src)_1." + uid : "";
    }();
    function isMasked(func) {
      return !!maskSrcKey && maskSrcKey in func;
    }
    module.exports = isMasked;
  }
});

// node_modules/lodash/_toSource.js
var require_toSource = __commonJS({
  "node_modules/lodash/_toSource.js"(exports, module) {
    var funcProto = Function.prototype;
    var funcToString = funcProto.toString;
    function toSource(func) {
      if (func != null) {
        try {
          return funcToString.call(func);
        } catch (e) {
        }
        try {
          return func + "";
        } catch (e) {
        }
      }
      return "";
    }
    module.exports = toSource;
  }
});

// node_modules/lodash/_baseIsNative.js
var require_baseIsNative = __commonJS({
  "node_modules/lodash/_baseIsNative.js"(exports, module) {
    var isFunction = require_isFunction();
    var isMasked = require_isMasked();
    var isObject = require_isObject();
    var toSource = require_toSource();
    var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;
    var reIsHostCtor = /^\[object .+?Constructor\]$/;
    var funcProto = Function.prototype;
    var objectProto = Object.prototype;
    var funcToString = funcProto.toString;
    var hasOwnProperty = objectProto.hasOwnProperty;
    var reIsNative = RegExp(
      "^" + funcToString.call(hasOwnProperty).replace(reRegExpChar, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
    );
    function baseIsNative(value) {
      if (!isObject(value) || isMasked(value)) {
        return false;
      }
      var pattern = isFunction(value) ? reIsNative : reIsHostCtor;
      return pattern.test(toSource(value));
    }
    module.exports = baseIsNative;
  }
});

// node_modules/lodash/_getValue.js
var require_getValue = __commonJS({
  "node_modules/lodash/_getValue.js"(exports, module) {
    function getValue(object, key) {
      return object == null ? void 0 : object[key];
    }
    module.exports = getValue;
  }
});

// node_modules/lodash/_getNative.js
var require_getNative = __commonJS({
  "node_modules/lodash/_getNative.js"(exports, module) {
    var baseIsNative = require_baseIsNative();
    var getValue = require_getValue();
    function getNative(object, key) {
      var value = getValue(object, key);
      return baseIsNative(value) ? value : void 0;
    }
    module.exports = getNative;
  }
});

// node_modules/lodash/_nativeCreate.js
var require_nativeCreate = __commonJS({
  "node_modules/lodash/_nativeCreate.js"(exports, module) {
    var getNative = require_getNative();
    var nativeCreate = getNative(Object, "create");
    module.exports = nativeCreate;
  }
});

// node_modules/lodash/_hashClear.js
var require_hashClear = __commonJS({
  "node_modules/lodash/_hashClear.js"(exports, module) {
    var nativeCreate = require_nativeCreate();
    function hashClear() {
      this.__data__ = nativeCreate ? nativeCreate(null) : {};
      this.size = 0;
    }
    module.exports = hashClear;
  }
});

// node_modules/lodash/_hashDelete.js
var require_hashDelete = __commonJS({
  "node_modules/lodash/_hashDelete.js"(exports, module) {
    function hashDelete(key) {
      var result = this.has(key) && delete this.__data__[key];
      this.size -= result ? 1 : 0;
      return result;
    }
    module.exports = hashDelete;
  }
});

// node_modules/lodash/_hashGet.js
var require_hashGet = __commonJS({
  "node_modules/lodash/_hashGet.js"(exports, module) {
    var nativeCreate = require_nativeCreate();
    var HASH_UNDEFINED = "__lodash_hash_undefined__";
    var objectProto = Object.prototype;
    var hasOwnProperty = objectProto.hasOwnProperty;
    function hashGet(key) {
      var data = this.__data__;
      if (nativeCreate) {
        var result = data[key];
        return result === HASH_UNDEFINED ? void 0 : result;
      }
      return hasOwnProperty.call(data, key) ? data[key] : void 0;
    }
    module.exports = hashGet;
  }
});

// node_modules/lodash/_hashHas.js
var require_hashHas = __commonJS({
  "node_modules/lodash/_hashHas.js"(exports, module) {
    var nativeCreate = require_nativeCreate();
    var objectProto = Object.prototype;
    var hasOwnProperty = objectProto.hasOwnProperty;
    function hashHas(key) {
      var data = this.__data__;
      return nativeCreate ? data[key] !== void 0 : hasOwnProperty.call(data, key);
    }
    module.exports = hashHas;
  }
});

// node_modules/lodash/_hashSet.js
var require_hashSet = __commonJS({
  "node_modules/lodash/_hashSet.js"(exports, module) {
    var nativeCreate = require_nativeCreate();
    var HASH_UNDEFINED = "__lodash_hash_undefined__";
    function hashSet(key, value) {
      var data = this.__data__;
      this.size += this.has(key) ? 0 : 1;
      data[key] = nativeCreate && value === void 0 ? HASH_UNDEFINED : value;
      return this;
    }
    module.exports = hashSet;
  }
});

// node_modules/lodash/_Hash.js
var require_Hash = __commonJS({
  "node_modules/lodash/_Hash.js"(exports, module) {
    var hashClear = require_hashClear();
    var hashDelete = require_hashDelete();
    var hashGet = require_hashGet();
    var hashHas = require_hashHas();
    var hashSet = require_hashSet();
    function Hash(entries) {
      var index = -1, length = entries == null ? 0 : entries.length;
      this.clear();
      while (++index < length) {
        var entry = entries[index];
        this.set(entry[0], entry[1]);
      }
    }
    Hash.prototype.clear = hashClear;
    Hash.prototype["delete"] = hashDelete;
    Hash.prototype.get = hashGet;
    Hash.prototype.has = hashHas;
    Hash.prototype.set = hashSet;
    module.exports = Hash;
  }
});

// node_modules/lodash/_listCacheClear.js
var require_listCacheClear = __commonJS({
  "node_modules/lodash/_listCacheClear.js"(exports, module) {
    function listCacheClear() {
      this.__data__ = [];
      this.size = 0;
    }
    module.exports = listCacheClear;
  }
});

// node_modules/lodash/eq.js
var require_eq = __commonJS({
  "node_modules/lodash/eq.js"(exports, module) {
    function eq(value, other) {
      return value === other || value !== value && other !== other;
    }
    module.exports = eq;
  }
});

// node_modules/lodash/_assocIndexOf.js
var require_assocIndexOf = __commonJS({
  "node_modules/lodash/_assocIndexOf.js"(exports, module) {
    var eq = require_eq();
    function assocIndexOf(array, key) {
      var length = array.length;
      while (length--) {
        if (eq(array[length][0], key)) {
          return length;
        }
      }
      return -1;
    }
    module.exports = assocIndexOf;
  }
});

// node_modules/lodash/_listCacheDelete.js
var require_listCacheDelete = __commonJS({
  "node_modules/lodash/_listCacheDelete.js"(exports, module) {
    var assocIndexOf = require_assocIndexOf();
    var arrayProto = Array.prototype;
    var splice = arrayProto.splice;
    function listCacheDelete(key) {
      var data = this.__data__, index = assocIndexOf(data, key);
      if (index < 0) {
        return false;
      }
      var lastIndex = data.length - 1;
      if (index == lastIndex) {
        data.pop();
      } else {
        splice.call(data, index, 1);
      }
      --this.size;
      return true;
    }
    module.exports = listCacheDelete;
  }
});

// node_modules/lodash/_listCacheGet.js
var require_listCacheGet = __commonJS({
  "node_modules/lodash/_listCacheGet.js"(exports, module) {
    var assocIndexOf = require_assocIndexOf();
    function listCacheGet(key) {
      var data = this.__data__, index = assocIndexOf(data, key);
      return index < 0 ? void 0 : data[index][1];
    }
    module.exports = listCacheGet;
  }
});

// node_modules/lodash/_listCacheHas.js
var require_listCacheHas = __commonJS({
  "node_modules/lodash/_listCacheHas.js"(exports, module) {
    var assocIndexOf = require_assocIndexOf();
    function listCacheHas(key) {
      return assocIndexOf(this.__data__, key) > -1;
    }
    module.exports = listCacheHas;
  }
});

// node_modules/lodash/_listCacheSet.js
var require_listCacheSet = __commonJS({
  "node_modules/lodash/_listCacheSet.js"(exports, module) {
    var assocIndexOf = require_assocIndexOf();
    function listCacheSet(key, value) {
      var data = this.__data__, index = assocIndexOf(data, key);
      if (index < 0) {
        ++this.size;
        data.push([key, value]);
      } else {
        data[index][1] = value;
      }
      return this;
    }
    module.exports = listCacheSet;
  }
});

// node_modules/lodash/_ListCache.js
var require_ListCache = __commonJS({
  "node_modules/lodash/_ListCache.js"(exports, module) {
    var listCacheClear = require_listCacheClear();
    var listCacheDelete = require_listCacheDelete();
    var listCacheGet = require_listCacheGet();
    var listCacheHas = require_listCacheHas();
    var listCacheSet = require_listCacheSet();
    function ListCache(entries) {
      var index = -1, length = entries == null ? 0 : entries.length;
      this.clear();
      while (++index < length) {
        var entry = entries[index];
        this.set(entry[0], entry[1]);
      }
    }
    ListCache.prototype.clear = listCacheClear;
    ListCache.prototype["delete"] = listCacheDelete;
    ListCache.prototype.get = listCacheGet;
    ListCache.prototype.has = listCacheHas;
    ListCache.prototype.set = listCacheSet;
    module.exports = ListCache;
  }
});

// node_modules/lodash/_Map.js
var require_Map = __commonJS({
  "node_modules/lodash/_Map.js"(exports, module) {
    var getNative = require_getNative();
    var root = require_root();
    var Map = getNative(root, "Map");
    module.exports = Map;
  }
});

// node_modules/lodash/_mapCacheClear.js
var require_mapCacheClear = __commonJS({
  "node_modules/lodash/_mapCacheClear.js"(exports, module) {
    var Hash = require_Hash();
    var ListCache = require_ListCache();
    var Map = require_Map();
    function mapCacheClear() {
      this.size = 0;
      this.__data__ = {
        "hash": new Hash(),
        "map": new (Map || ListCache)(),
        "string": new Hash()
      };
    }
    module.exports = mapCacheClear;
  }
});

// node_modules/lodash/_isKeyable.js
var require_isKeyable = __commonJS({
  "node_modules/lodash/_isKeyable.js"(exports, module) {
    function isKeyable(value) {
      var type = typeof value;
      return type == "string" || type == "number" || type == "symbol" || type == "boolean" ? value !== "__proto__" : value === null;
    }
    module.exports = isKeyable;
  }
});

// node_modules/lodash/_getMapData.js
var require_getMapData = __commonJS({
  "node_modules/lodash/_getMapData.js"(exports, module) {
    var isKeyable = require_isKeyable();
    function getMapData(map, key) {
      var data = map.__data__;
      return isKeyable(key) ? data[typeof key == "string" ? "string" : "hash"] : data.map;
    }
    module.exports = getMapData;
  }
});

// node_modules/lodash/_mapCacheDelete.js
var require_mapCacheDelete = __commonJS({
  "node_modules/lodash/_mapCacheDelete.js"(exports, module) {
    var getMapData = require_getMapData();
    function mapCacheDelete(key) {
      var result = getMapData(this, key)["delete"](key);
      this.size -= result ? 1 : 0;
      return result;
    }
    module.exports = mapCacheDelete;
  }
});

// node_modules/lodash/_mapCacheGet.js
var require_mapCacheGet = __commonJS({
  "node_modules/lodash/_mapCacheGet.js"(exports, module) {
    var getMapData = require_getMapData();
    function mapCacheGet(key) {
      return getMapData(this, key).get(key);
    }
    module.exports = mapCacheGet;
  }
});

// node_modules/lodash/_mapCacheHas.js
var require_mapCacheHas = __commonJS({
  "node_modules/lodash/_mapCacheHas.js"(exports, module) {
    var getMapData = require_getMapData();
    function mapCacheHas(key) {
      return getMapData(this, key).has(key);
    }
    module.exports = mapCacheHas;
  }
});

// node_modules/lodash/_mapCacheSet.js
var require_mapCacheSet = __commonJS({
  "node_modules/lodash/_mapCacheSet.js"(exports, module) {
    var getMapData = require_getMapData();
    function mapCacheSet(key, value) {
      var data = getMapData(this, key), size = data.size;
      data.set(key, value);
      this.size += data.size == size ? 0 : 1;
      return this;
    }
    module.exports = mapCacheSet;
  }
});

// node_modules/lodash/_MapCache.js
var require_MapCache = __commonJS({
  "node_modules/lodash/_MapCache.js"(exports, module) {
    var mapCacheClear = require_mapCacheClear();
    var mapCacheDelete = require_mapCacheDelete();
    var mapCacheGet = require_mapCacheGet();
    var mapCacheHas = require_mapCacheHas();
    var mapCacheSet = require_mapCacheSet();
    function MapCache(entries) {
      var index = -1, length = entries == null ? 0 : entries.length;
      this.clear();
      while (++index < length) {
        var entry = entries[index];
        this.set(entry[0], entry[1]);
      }
    }
    MapCache.prototype.clear = mapCacheClear;
    MapCache.prototype["delete"] = mapCacheDelete;
    MapCache.prototype.get = mapCacheGet;
    MapCache.prototype.has = mapCacheHas;
    MapCache.prototype.set = mapCacheSet;
    module.exports = MapCache;
  }
});

// node_modules/lodash/_setCacheAdd.js
var require_setCacheAdd = __commonJS({
  "node_modules/lodash/_setCacheAdd.js"(exports, module) {
    var HASH_UNDEFINED = "__lodash_hash_undefined__";
    function setCacheAdd(value) {
      this.__data__.set(value, HASH_UNDEFINED);
      return this;
    }
    module.exports = setCacheAdd;
  }
});

// node_modules/lodash/_setCacheHas.js
var require_setCacheHas = __commonJS({
  "node_modules/lodash/_setCacheHas.js"(exports, module) {
    function setCacheHas(value) {
      return this.__data__.has(value);
    }
    module.exports = setCacheHas;
  }
});

// node_modules/lodash/_SetCache.js
var require_SetCache = __commonJS({
  "node_modules/lodash/_SetCache.js"(exports, module) {
    var MapCache = require_MapCache();
    var setCacheAdd = require_setCacheAdd();
    var setCacheHas = require_setCacheHas();
    function SetCache(values) {
      var index = -1, length = values == null ? 0 : values.length;
      this.__data__ = new MapCache();
      while (++index < length) {
        this.add(values[index]);
      }
    }
    SetCache.prototype.add = SetCache.prototype.push = setCacheAdd;
    SetCache.prototype.has = setCacheHas;
    module.exports = SetCache;
  }
});

// node_modules/lodash/_baseFindIndex.js
var require_baseFindIndex = __commonJS({
  "node_modules/lodash/_baseFindIndex.js"(exports, module) {
    function baseFindIndex(array, predicate, fromIndex, fromRight) {
      var length = array.length, index = fromIndex + (fromRight ? 1 : -1);
      while (fromRight ? index-- : ++index < length) {
        if (predicate(array[index], index, array)) {
          return index;
        }
      }
      return -1;
    }
    module.exports = baseFindIndex;
  }
});

// node_modules/lodash/_baseIsNaN.js
var require_baseIsNaN = __commonJS({
  "node_modules/lodash/_baseIsNaN.js"(exports, module) {
    function baseIsNaN(value) {
      return value !== value;
    }
    module.exports = baseIsNaN;
  }
});

// node_modules/lodash/_strictIndexOf.js
var require_strictIndexOf = __commonJS({
  "node_modules/lodash/_strictIndexOf.js"(exports, module) {
    function strictIndexOf(array, value, fromIndex) {
      var index = fromIndex - 1, length = array.length;
      while (++index < length) {
        if (array[index] === value) {
          return index;
        }
      }
      return -1;
    }
    module.exports = strictIndexOf;
  }
});

// node_modules/lodash/_baseIndexOf.js
var require_baseIndexOf = __commonJS({
  "node_modules/lodash/_baseIndexOf.js"(exports, module) {
    var baseFindIndex = require_baseFindIndex();
    var baseIsNaN = require_baseIsNaN();
    var strictIndexOf = require_strictIndexOf();
    function baseIndexOf(array, value, fromIndex) {
      return value === value ? strictIndexOf(array, value, fromIndex) : baseFindIndex(array, baseIsNaN, fromIndex);
    }
    module.exports = baseIndexOf;
  }
});

// node_modules/lodash/_arrayIncludes.js
var require_arrayIncludes = __commonJS({
  "node_modules/lodash/_arrayIncludes.js"(exports, module) {
    var baseIndexOf = require_baseIndexOf();
    function arrayIncludes(array, value) {
      var length = array == null ? 0 : array.length;
      return !!length && baseIndexOf(array, value, 0) > -1;
    }
    module.exports = arrayIncludes;
  }
});

// node_modules/lodash/_arrayIncludesWith.js
var require_arrayIncludesWith = __commonJS({
  "node_modules/lodash/_arrayIncludesWith.js"(exports, module) {
    function arrayIncludesWith(array, value, comparator) {
      var index = -1, length = array == null ? 0 : array.length;
      while (++index < length) {
        if (comparator(value, array[index])) {
          return true;
        }
      }
      return false;
    }
    module.exports = arrayIncludesWith;
  }
});

// node_modules/lodash/_arrayMap.js
var require_arrayMap = __commonJS({
  "node_modules/lodash/_arrayMap.js"(exports, module) {
    function arrayMap(array, iteratee) {
      var index = -1, length = array == null ? 0 : array.length, result = Array(length);
      while (++index < length) {
        result[index] = iteratee(array[index], index, array);
      }
      return result;
    }
    module.exports = arrayMap;
  }
});

// node_modules/lodash/_baseUnary.js
var require_baseUnary = __commonJS({
  "node_modules/lodash/_baseUnary.js"(exports, module) {
    function baseUnary(func) {
      return function(value) {
        return func(value);
      };
    }
    module.exports = baseUnary;
  }
});

// node_modules/lodash/_cacheHas.js
var require_cacheHas = __commonJS({
  "node_modules/lodash/_cacheHas.js"(exports, module) {
    function cacheHas(cache, key) {
      return cache.has(key);
    }
    module.exports = cacheHas;
  }
});

// node_modules/lodash/_baseDifference.js
var require_baseDifference = __commonJS({
  "node_modules/lodash/_baseDifference.js"(exports, module) {
    var SetCache = require_SetCache();
    var arrayIncludes = require_arrayIncludes();
    var arrayIncludesWith = require_arrayIncludesWith();
    var arrayMap = require_arrayMap();
    var baseUnary = require_baseUnary();
    var cacheHas = require_cacheHas();
    var LARGE_ARRAY_SIZE = 200;
    function baseDifference(array, values, iteratee, comparator) {
      var index = -1, includes = arrayIncludes, isCommon = true, length = array.length, result = [], valuesLength = values.length;
      if (!length) {
        return result;
      }
      if (iteratee) {
        values = arrayMap(values, baseUnary(iteratee));
      }
      if (comparator) {
        includes = arrayIncludesWith;
        isCommon = false;
      } else if (values.length >= LARGE_ARRAY_SIZE) {
        includes = cacheHas;
        isCommon = false;
        values = new SetCache(values);
      }
      outer:
        while (++index < length) {
          var value = array[index], computed = iteratee == null ? value : iteratee(value);
          value = comparator || value !== 0 ? value : 0;
          if (isCommon && computed === computed) {
            var valuesIndex = valuesLength;
            while (valuesIndex--) {
              if (values[valuesIndex] === computed) {
                continue outer;
              }
            }
            result.push(value);
          } else if (!includes(values, computed, comparator)) {
            result.push(value);
          }
        }
      return result;
    }
    module.exports = baseDifference;
  }
});

// node_modules/lodash/_arrayPush.js
var require_arrayPush = __commonJS({
  "node_modules/lodash/_arrayPush.js"(exports, module) {
    function arrayPush(array, values) {
      var index = -1, length = values.length, offset = array.length;
      while (++index < length) {
        array[offset + index] = values[index];
      }
      return array;
    }
    module.exports = arrayPush;
  }
});

// node_modules/lodash/isObjectLike.js
var require_isObjectLike = __commonJS({
  "node_modules/lodash/isObjectLike.js"(exports, module) {
    function isObjectLike(value) {
      return value != null && typeof value == "object";
    }
    module.exports = isObjectLike;
  }
});

// node_modules/lodash/_baseIsArguments.js
var require_baseIsArguments = __commonJS({
  "node_modules/lodash/_baseIsArguments.js"(exports, module) {
    var baseGetTag = require_baseGetTag();
    var isObjectLike = require_isObjectLike();
    var argsTag = "[object Arguments]";
    function baseIsArguments(value) {
      return isObjectLike(value) && baseGetTag(value) == argsTag;
    }
    module.exports = baseIsArguments;
  }
});

// node_modules/lodash/isArguments.js
var require_isArguments = __commonJS({
  "node_modules/lodash/isArguments.js"(exports, module) {
    var baseIsArguments = require_baseIsArguments();
    var isObjectLike = require_isObjectLike();
    var objectProto = Object.prototype;
    var hasOwnProperty = objectProto.hasOwnProperty;
    var propertyIsEnumerable = objectProto.propertyIsEnumerable;
    var isArguments = baseIsArguments(function() {
      return arguments;
    }()) ? baseIsArguments : function(value) {
      return isObjectLike(value) && hasOwnProperty.call(value, "callee") && !propertyIsEnumerable.call(value, "callee");
    };
    module.exports = isArguments;
  }
});

// node_modules/lodash/isArray.js
var require_isArray = __commonJS({
  "node_modules/lodash/isArray.js"(exports, module) {
    var isArray = Array.isArray;
    module.exports = isArray;
  }
});

// node_modules/lodash/_isFlattenable.js
var require_isFlattenable = __commonJS({
  "node_modules/lodash/_isFlattenable.js"(exports, module) {
    var Symbol2 = require_Symbol();
    var isArguments = require_isArguments();
    var isArray = require_isArray();
    var spreadableSymbol = Symbol2 ? Symbol2.isConcatSpreadable : void 0;
    function isFlattenable(value) {
      return isArray(value) || isArguments(value) || !!(spreadableSymbol && value && value[spreadableSymbol]);
    }
    module.exports = isFlattenable;
  }
});

// node_modules/lodash/_baseFlatten.js
var require_baseFlatten = __commonJS({
  "node_modules/lodash/_baseFlatten.js"(exports, module) {
    var arrayPush = require_arrayPush();
    var isFlattenable = require_isFlattenable();
    function baseFlatten(array, depth, predicate, isStrict, result) {
      var index = -1, length = array.length;
      predicate || (predicate = isFlattenable);
      result || (result = []);
      while (++index < length) {
        var value = array[index];
        if (depth > 0 && predicate(value)) {
          if (depth > 1) {
            baseFlatten(value, depth - 1, predicate, isStrict, result);
          } else {
            arrayPush(result, value);
          }
        } else if (!isStrict) {
          result[result.length] = value;
        }
      }
      return result;
    }
    module.exports = baseFlatten;
  }
});

// node_modules/lodash/identity.js
var require_identity = __commonJS({
  "node_modules/lodash/identity.js"(exports, module) {
    function identity(value) {
      return value;
    }
    module.exports = identity;
  }
});

// node_modules/lodash/_apply.js
var require_apply = __commonJS({
  "node_modules/lodash/_apply.js"(exports, module) {
    function apply(func, thisArg, args) {
      switch (args.length) {
        case 0:
          return func.call(thisArg);
        case 1:
          return func.call(thisArg, args[0]);
        case 2:
          return func.call(thisArg, args[0], args[1]);
        case 3:
          return func.call(thisArg, args[0], args[1], args[2]);
      }
      return func.apply(thisArg, args);
    }
    module.exports = apply;
  }
});

// node_modules/lodash/_overRest.js
var require_overRest = __commonJS({
  "node_modules/lodash/_overRest.js"(exports, module) {
    var apply = require_apply();
    var nativeMax = Math.max;
    function overRest(func, start, transform) {
      start = nativeMax(start === void 0 ? func.length - 1 : start, 0);
      return function() {
        var args = arguments, index = -1, length = nativeMax(args.length - start, 0), array = Array(length);
        while (++index < length) {
          array[index] = args[start + index];
        }
        index = -1;
        var otherArgs = Array(start + 1);
        while (++index < start) {
          otherArgs[index] = args[index];
        }
        otherArgs[start] = transform(array);
        return apply(func, this, otherArgs);
      };
    }
    module.exports = overRest;
  }
});

// node_modules/lodash/constant.js
var require_constant = __commonJS({
  "node_modules/lodash/constant.js"(exports, module) {
    function constant(value) {
      return function() {
        return value;
      };
    }
    module.exports = constant;
  }
});

// node_modules/lodash/_defineProperty.js
var require_defineProperty = __commonJS({
  "node_modules/lodash/_defineProperty.js"(exports, module) {
    var getNative = require_getNative();
    var defineProperty = function() {
      try {
        var func = getNative(Object, "defineProperty");
        func({}, "", {});
        return func;
      } catch (e) {
      }
    }();
    module.exports = defineProperty;
  }
});

// node_modules/lodash/_baseSetToString.js
var require_baseSetToString = __commonJS({
  "node_modules/lodash/_baseSetToString.js"(exports, module) {
    var constant = require_constant();
    var defineProperty = require_defineProperty();
    var identity = require_identity();
    var baseSetToString = !defineProperty ? identity : function(func, string) {
      return defineProperty(func, "toString", {
        "configurable": true,
        "enumerable": false,
        "value": constant(string),
        "writable": true
      });
    };
    module.exports = baseSetToString;
  }
});

// node_modules/lodash/_shortOut.js
var require_shortOut = __commonJS({
  "node_modules/lodash/_shortOut.js"(exports, module) {
    var HOT_COUNT = 800;
    var HOT_SPAN = 16;
    var nativeNow = Date.now;
    function shortOut(func) {
      var count = 0, lastCalled = 0;
      return function() {
        var stamp = nativeNow(), remaining = HOT_SPAN - (stamp - lastCalled);
        lastCalled = stamp;
        if (remaining > 0) {
          if (++count >= HOT_COUNT) {
            return arguments[0];
          }
        } else {
          count = 0;
        }
        return func.apply(void 0, arguments);
      };
    }
    module.exports = shortOut;
  }
});

// node_modules/lodash/_setToString.js
var require_setToString = __commonJS({
  "node_modules/lodash/_setToString.js"(exports, module) {
    var baseSetToString = require_baseSetToString();
    var shortOut = require_shortOut();
    var setToString = shortOut(baseSetToString);
    module.exports = setToString;
  }
});

// node_modules/lodash/_baseRest.js
var require_baseRest = __commonJS({
  "node_modules/lodash/_baseRest.js"(exports, module) {
    var identity = require_identity();
    var overRest = require_overRest();
    var setToString = require_setToString();
    function baseRest(func, start) {
      return setToString(overRest(func, start, identity), func + "");
    }
    module.exports = baseRest;
  }
});

// node_modules/lodash/isLength.js
var require_isLength = __commonJS({
  "node_modules/lodash/isLength.js"(exports, module) {
    var MAX_SAFE_INTEGER = 9007199254740991;
    function isLength(value) {
      return typeof value == "number" && value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER;
    }
    module.exports = isLength;
  }
});

// node_modules/lodash/isArrayLike.js
var require_isArrayLike = __commonJS({
  "node_modules/lodash/isArrayLike.js"(exports, module) {
    var isFunction = require_isFunction();
    var isLength = require_isLength();
    function isArrayLike(value) {
      return value != null && isLength(value.length) && !isFunction(value);
    }
    module.exports = isArrayLike;
  }
});

// node_modules/lodash/isArrayLikeObject.js
var require_isArrayLikeObject = __commonJS({
  "node_modules/lodash/isArrayLikeObject.js"(exports, module) {
    var isArrayLike = require_isArrayLike();
    var isObjectLike = require_isObjectLike();
    function isArrayLikeObject(value) {
      return isObjectLike(value) && isArrayLike(value);
    }
    module.exports = isArrayLikeObject;
  }
});

// node_modules/lodash/difference.js
var require_difference = __commonJS({
  "node_modules/lodash/difference.js"(exports, module) {
    var baseDifference = require_baseDifference();
    var baseFlatten = require_baseFlatten();
    var baseRest = require_baseRest();
    var isArrayLikeObject = require_isArrayLikeObject();
    var difference = baseRest(function(array, values) {
      return isArrayLikeObject(array) ? baseDifference(array, baseFlatten(values, 1, isArrayLikeObject, true)) : [];
    });
    module.exports = difference;
  }
});

// node_modules/@dynatrace/sdk-automation-labs/lib/actions/actions.js
var require_actions = __commonJS({
  "node_modules/@dynatrace/sdk-automation-labs/lib/actions/actions.js"(exports) {
    "use strict";
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.BaseAction = exports.validateRequiredAttributes = void 0;
    var difference_1 = __importDefault(require_difference());
    var isObjectLike_1 = __importDefault(require_isObjectLike());
    var LoggerImpl = class {
      lines = [];
      log(level, message) {
        this.lines.push(`${`[${level.toUpperCase()}]`.padEnd(9)} ${message}`);
      }
      dump() {
        return this.lines.length > 0 ? this.lines.join("\n") : "";
      }
      debug(message) {
        console.log(message);
      }
      info(message) {
        this.log("info", message);
      }
      warn(message) {
        this.log("warn", message);
      }
      error(message) {
        this.log("error", message);
      }
    };
    function validateRequiredAttributes3(input, required) {
      if (required && required.length && !(0, isObjectLike_1.default)(input)) {
        throw new Error(`Input must be an object.`);
      }
      const missing = (0, difference_1.default)(required, Object.getOwnPropertyNames(input));
      if (missing.length) {
        throw new Error(`Input fields "${missing}" are missing.`);
      }
    }
    exports.validateRequiredAttributes = validateRequiredAttributes3;
    var BaseAction2 = class {
      logger;
      actionExecuted = false;
      /**
       * @throws {Error} If action has been already executed
       */
      checkIfCanRun() {
        if (this.actionExecuted) {
          throw Error("Given action instance can be run only once.");
        }
        this.actionExecuted = true;
      }
      async runAction(rawPayload) {
        const logger = new LoggerImpl();
        this.logger = logger;
        let output = null;
        try {
          this.checkIfCanRun();
          await this.initialize(rawPayload);
          output = {
            result: await this.run() || null
          };
        } catch (error) {
          let errorContent;
          if (error?.message) {
            errorContent = error.message;
          } else {
            errorContent = "" + error;
          }
          output = { error: errorContent };
        } finally {
          output.logs = logger.dump();
        }
        return output;
      }
    };
    exports.BaseAction = BaseAction2;
  }
});

// node_modules/@dynatrace-sdk/error-handlers/cjs/index.js
var require_cjs = __commonJS({
  "node_modules/@dynatrace-sdk/error-handlers/cjs/index.js"(exports, module) {
    "use strict";
    var __defProp2 = Object.defineProperty;
    var __getOwnPropDesc2 = Object.getOwnPropertyDescriptor;
    var __getOwnPropNames2 = Object.getOwnPropertyNames;
    var __hasOwnProp2 = Object.prototype.hasOwnProperty;
    var __export = (target, all) => {
      for (var name in all)
        __defProp2(target, name, { get: all[name], enumerable: true });
    };
    var __copyProps2 = (to, from, except, desc) => {
      if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames2(from))
          if (!__hasOwnProp2.call(to, key) && key !== except)
            __defProp2(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc2(from, key)) || desc.enumerable });
      }
      return to;
    };
    var __toCommonJS = (mod) => __copyProps2(__defProp2({}, "__esModule", { value: true }), mod);
    var src_exports = {};
    __export(src_exports, {
      ErrorType: () => ErrorType,
      addGlobalErrorSerializer: () => addGlobalErrorSerializer,
      isGlobalErrorSerializerSupported: () => isGlobalErrorSerializerSupported
    });
    module.exports = __toCommonJS(src_exports);
    var getGlobalWithDtRuntime = () => typeof globalThis !== "undefined" ? globalThis : window;
    function addGlobalErrorSerializer(serializer) {
      const addGlobalErrorSerializerFunc = getAddGlobalErrorSerializer();
      if (typeof addGlobalErrorSerializerFunc === "function") {
        addGlobalErrorSerializerFunc(serializer);
      } else {
        console.warn("Missing addGlobalErrorSerializer function from sdk-web-runtime.");
      }
    }
    function isGlobalErrorSerializerSupported() {
      return typeof getAddGlobalErrorSerializer() === "function";
    }
    function getAddGlobalErrorSerializer() {
      return getGlobalWithDtRuntime().dtRuntime?.errorHandlers?.addGlobalErrorSerializer;
    }
    var ErrorType = /* @__PURE__ */ ((ErrorType2) => {
      ErrorType2["COMMON"] = "JS Error";
      ErrorType2["HTTP"] = "Http Error";
      return ErrorType2;
    })(ErrorType || {});
  }
});

// node_modules/@dynatrace-sdk/http-client/cjs/index.js
var require_cjs2 = __commonJS({
  "node_modules/@dynatrace-sdk/http-client/cjs/index.js"(exports, module) {
    "use strict";
    var __defProp2 = Object.defineProperty;
    var __getOwnPropDesc2 = Object.getOwnPropertyDescriptor;
    var __getOwnPropNames2 = Object.getOwnPropertyNames;
    var __hasOwnProp2 = Object.prototype.hasOwnProperty;
    var __export = (target, all) => {
      for (var name in all)
        __defProp2(target, name, { get: all[name], enumerable: true });
    };
    var __copyProps2 = (to, from, except, desc) => {
      if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames2(from))
          if (!__hasOwnProp2.call(to, key) && key !== except)
            __defProp2(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc2(from, key)) || desc.enumerable });
      }
      return to;
    };
    var __toCommonJS = (mod) => __copyProps2(__defProp2({}, "__esModule", { value: true }), mod);
    var src_exports = {};
    __export(src_exports, {
      PlatformAbortController: () => AbortController,
      PlatformAbortSignal: () => AbortSignal,
      PlatformBaseError: () => BaseError,
      PlatformBinary: () => Binary,
      PlatformDataTypeError: () => DataTypeError,
      PlatformHttpClient: () => HttpClient,
      PlatformHttpClientAbortError: () => HttpClientAbortError,
      PlatformHttpClientRequestError: () => HttpClientRequestError,
      PlatformHttpClientResponse: () => HttpClientResponse,
      PlatformHttpClientResponseError: () => HttpClientResponseError,
      PlatformUnsupportedOperationError: () => UnsupportedOperationError,
      httpClient: () => httpClient
    });
    module.exports = __toCommonJS(src_exports);
    var AbortController = globalThis.AbortController;
    var AbortSignal = globalThis.AbortSignal;
    var BaseError = class extends Error {
      constructor(message, cause) {
        super(message);
        this.cause = cause;
      }
    };
    var UnsupportedOperationError = class extends BaseError {
      name = "UnsupportedOperationError";
      constructor(message, cause) {
        super(message, cause);
      }
    };
    function getImpl(data, type) {
      const response = new Response(data);
      switch (type) {
        case "text":
          return response.text();
        case "json":
          return response.json();
        case "array-buffer":
          return response.arrayBuffer();
        case "blob":
          return response.blob();
        case "readable-stream":
          return response.body;
      }
      throw new UnsupportedOperationError(`Unsupported binary type: ${type}.`);
    }
    var Binary = class {
      constructor(data) {
        this.data = data;
      }
      static fromText(text) {
        return new Binary(new Blob([text]));
      }
      static fromJson(json) {
        return new Binary(new Blob([JSON.stringify(json)]));
      }
      static from(data) {
        if (data instanceof Blob || data instanceof ArrayBuffer || data instanceof ReadableStream) {
          return new Binary(data);
        } else {
          throw new UnsupportedOperationError("Unsupported binary type.");
        }
      }
      get(type) {
        return getImpl(this.data, type);
      }
    };
    function isBinary(body) {
      return typeof body.get === "function";
    }
    var DataTypeError = class extends BaseError {
      name = "DataTypeError";
      constructor(message, cause) {
        super(message, cause);
      }
    };
    var defaultStatusValidator = (status) => 200 <= status && status < 300;
    function encodeTextRequestBody(body) {
      return String(body);
    }
    function encodeJsonRequestBody(body) {
      return JSON.stringify(body);
    }
    async function encodeBinaryFormDataField(field) {
      if (field instanceof ArrayBuffer || field instanceof Blob) {
        return field;
      } else if (field instanceof ReadableStream) {
        return new Response(field).arrayBuffer();
      } else if (isBinary(field)) {
        return field.get("array-buffer");
      } else {
        throw new DataTypeError("Cannot encode form data field as binary type.");
      }
    }
    async function encodeFormDataRequestBody(body) {
      const formData = new FormData();
      for (const field of body) {
        switch (field.type) {
          case "text":
            formData.append(field.name, encodeTextRequestBody(field.value));
            break;
          case "json":
            formData.append(
              field.name,
              new Blob([encodeJsonRequestBody(field.value)], {
                type: field.contentType ?? "application/json"
              }),
              field.filename ?? "json"
            );
            break;
          case "binary": {
            if (field.value instanceof File) {
              const file = field.value;
              formData.append(
                field.name,
                new File([file], field.filename ?? file.name, {
                  type: field.contentType ?? file.type ?? "application/octet-stream",
                  lastModified: file.lastModified
                }),
                field.filename ?? file.name
              );
            } else {
              const blobType = "type" in field.value ? field.value.type : void 0;
              formData.append(
                field.name,
                new Blob([await encodeBinaryFormDataField(field.value)], {
                  type: field.contentType ?? blobType ?? "application/octet-stream"
                }),
                field.filename ?? "binary"
              );
            }
            break;
          }
        }
      }
      return formData;
    }
    async function encodeBinaryRequestBody(body) {
      if (body instanceof Blob || body instanceof ArrayBuffer || body instanceof ReadableStream) {
        return body;
      } else if (isBinary(body)) {
        try {
          return await body.get("array-buffer");
        } catch (e) {
          throw new DataTypeError("Cannot encode body as binary type.", e);
        }
      } else {
        throw new DataTypeError("Cannot encode body as binary type.");
      }
    }
    async function encodeRequestBody(body, requestBodyType) {
      switch (requestBodyType) {
        case "text":
          return encodeTextRequestBody(body);
        case "json":
          return encodeJsonRequestBody(body);
        case "form-data":
          return await encodeFormDataRequestBody(body);
        case "binary":
          return await encodeBinaryRequestBody(body);
      }
      throw new DataTypeError(`Invalid body type: '${requestBodyType}'`);
    }
    function getContentTypeBy(bodyType) {
      switch (bodyType) {
        case "json":
          return "application/json";
        case "text":
          return "text/plain";
        case "binary":
          return "application/octet-stream";
      }
      throw new DataTypeError(`Invalid body type: '${bodyType}'`);
    }
    function normalizeHeaders(headers) {
      if (headers["Content-Type"]?.startsWith("multipart/")) {
        const { "Content-Type": contentTypeHeader, ...normalizedHeaders } = headers;
        return normalizedHeaders;
      }
      return headers;
    }
    function applyContentTypeHeader(headers, requestBodyType) {
      const normalizedHeaders = headers ? normalizeHeaders(headers) : void 0;
      const isContentTypePresent = Object.keys(normalizedHeaders ?? {}).some(
        (header) => header.toLowerCase() === "content-type"
      );
      if (!isContentTypePresent && requestBodyType !== "form-data") {
        return {
          "content-type": getContentTypeBy(requestBodyType),
          ...normalizedHeaders
        };
      }
      return normalizedHeaders;
    }
    var HttpClientAbortError = class extends Error {
      constructor(cause) {
        super(
          typeof cause?.message === "string" ? `Request aborted: ${cause.message}` : "Request aborted."
        );
        this.cause = cause;
      }
      name = "AbortError";
    };
    var throwIfAbortError = (e) => {
      if (e instanceof Error && e.name === "AbortError") {
        throw new HttpClientAbortError(e);
      }
    };
    var HttpClientRequestError = class extends BaseError {
      constructor(cause) {
        super(
          typeof cause?.message === "string" ? `Request failed: ${cause.message}` : "Request failed."
        );
        this.cause = cause;
      }
      name = "RequestError";
    };
    function emptyReadableStream() {
      return new ReadableStream({
        start(controller) {
          controller.close();
        }
      });
    }
    async function decodeTextResponseBody(response) {
      return response.body !== null ? response.text() : "";
    }
    async function decodeJsonResponseBody(response) {
      return response.body !== null ? response.json() : null;
    }
    async function decodeBinaryResponseBody(response) {
      return Binary.from(decodeReadableStreamResponseBody(response));
    }
    async function decodeFormDataResponseBody(response) {
      if (response.body === null) {
        return [];
      } else {
        const formData = await response.formData();
        const result = [];
        formData.forEach((value, key) => {
          if (value instanceof File) {
            result.push({
              type: "binary",
              name: key,
              contentType: value.type,
              filename: value.name,
              value: Binary.from(value)
            });
          } else {
            result.push({
              type: "text",
              name: key,
              value
            });
          }
        });
        return result;
      }
    }
    async function decodeArrayBufferResponseBody(response) {
      return response !== null ? response.arrayBuffer() : new ArrayBuffer(0);
    }
    async function decodeBlobResponseBody(response) {
      return response !== null ? response.blob() : new Blob();
    }
    function decodeReadableStreamResponseBody(response) {
      return response.body !== null ? response.body : emptyReadableStream();
    }
    function throwResponseBodyTypeError(response, responseBodyType, cause) {
      throw new DataTypeError(
        `Response body does not conform to the specified response body type: '${responseBodyType}'. The content type of the response is '${response.headers.get(
          "Content-Type"
        )}'. Response status is '${response.status}'. Response source is '${response.headers.get(
          "dynatrace-response-source"
        )}'`,
        cause
      );
    }
    async function decodeAsyncResponseBody(response, responseBodyType) {
      try {
        switch (responseBodyType) {
          case "text":
            return await decodeTextResponseBody(response);
          case "json":
            return await decodeJsonResponseBody(response);
          case "binary":
            return await decodeBinaryResponseBody(response);
          case "form-data":
            return await decodeFormDataResponseBody(response);
          case "array-buffer":
            return await decodeArrayBufferResponseBody(response);
          case "blob":
            return await decodeBlobResponseBody(response);
        }
      } catch (e) {
        throwIfAbortError(e);
        throwResponseBodyTypeError(response, responseBodyType, e);
      }
    }
    function decodeSyncResponseBody(response, responseBodyType) {
      try {
        return decodeReadableStreamResponseBody(response);
      } catch (e) {
        throwIfAbortError(e);
        throwResponseBodyTypeError(response, responseBodyType, e);
      }
    }
    function decodeResponseBodyImpl(response, responseBodyType) {
      switch (responseBodyType) {
        case "text":
        case "json":
        case "binary":
        case "form-data":
        case "array-buffer":
        case "blob":
          return decodeAsyncResponseBody(response, responseBodyType);
        case "readable-stream":
          return decodeSyncResponseBody(response, responseBodyType);
      }
      switch (responseBodyType) {
        case "buffer":
        case "stream":
          throw new UnsupportedOperationError(`Unsupported response body type: '${responseBodyType}'`);
        default:
          throw new DataTypeError(`Invalid body type: '${responseBodyType}'`);
      }
    }
    function decodeResponseBody(response, responseBodyType) {
      return decodeResponseBodyImpl(response, responseBodyType);
    }
    var HttpClientResponse = class {
      constructor(response) {
        this.response = response;
      }
      get url() {
        return this.response.url;
      }
      get status() {
        return this.response.status;
      }
      get statusText() {
        return this.response.statusText;
      }
      get headers() {
        const headers = {};
        this.response.headers.forEach((value, key) => {
          headers[key] = value;
        });
        return headers;
      }
      body(responseBodyType = "json") {
        return decodeResponseBody(this.response, responseBodyType);
      }
    };
    var import_error_handlers = require_cjs();
    function getMessageFromObject(obj) {
      if (typeof obj === "object" && obj !== null && typeof obj.message === "string") {
        return obj.message;
      }
    }
    async function parseResponse(response) {
      let consumedBody;
      try {
        consumedBody = await response.body("text");
      } catch (e) {
        const bodyError = `Response body is not available. ${e?.message ?? "Unknown error occurred."}`;
        return {
          message: bodyError.substring(0, 100),
          body: bodyError
        };
      }
      try {
        const jsonBody = JSON.parse(consumedBody);
        if (typeof jsonBody === "object" && jsonBody !== null) {
          return {
            message: getMessageFromObject(jsonBody.error) || getMessageFromObject(jsonBody) || consumedBody.substring(0, 100),
            body: jsonBody,
            errorRef: jsonBody.error?.details?.errorRef
          };
        } else {
          return {
            message: consumedBody.substring(0, 100),
            body: consumedBody
          };
        }
      } catch (e) {
        return {
          message: consumedBody.substring(0, 100),
          body: consumedBody
        };
      }
    }
    var httpClientResponseErrorSerializer = async (error) => {
      if (error instanceof HttpClientResponseError) {
        const status = error.response.status;
        const { message, body, errorRef } = await parseResponse(error.response);
        const optionalErrorRef = errorRef ? { errorRef } : {};
        return {
          name: error.name,
          status,
          message,
          stack: error.stack,
          type: import_error_handlers.ErrorType.HTTP,
          body,
          ...optionalErrorRef
        };
      }
    };
    var errorSerializerAdded = false;
    function addHttpClientResponseErrorSerializer() {
      if (!errorSerializerAdded && (0, import_error_handlers.isGlobalErrorSerializerSupported)()) {
        errorSerializerAdded = true;
        (0, import_error_handlers.addGlobalErrorSerializer)(httpClientResponseErrorSerializer);
      }
    }
    var HttpClientResponseError = class extends BaseError {
      name = "ResponseError";
      response;
      constructor(response) {
        addHttpClientResponseErrorSerializer();
        super(`HTTP Error ${response.status}: ${response.statusText}`);
        this.response = new HttpClientResponse(response);
      }
    };
    var send = async (info, init) => {
      try {
        return await fetch(info, init);
      } catch (e) {
        throwIfAbortError(e);
        throw new HttpClientRequestError(e);
      }
    };
    var HttpClient = class {
      async send(options) {
        const { statusValidator = defaultStatusValidator } = options;
        const requestBodyType = options.requestBodyType ?? "json";
        const body = options.body !== void 0 ? await encodeRequestBody(options.body, requestBodyType) : void 0;
        const response = await send(options.url, {
          method: options.method,
          headers: applyContentTypeHeader(options.headers, requestBodyType),
          signal: options.abortSignal,
          body
        });
        const ok = statusValidator(response.status);
        if (ok) {
          return new HttpClientResponse(response);
        } else {
          throw new HttpClientResponseError(response);
        }
      }
    };
    var httpClient = new HttpClient();
  }
});

// node_modules/@dynatrace/sdk-automation-labs/node_modules/@dynatrace-sdk/client-app-settings/cjs/index.js
var require_cjs3 = __commonJS({
  "node_modules/@dynatrace/sdk-automation-labs/node_modules/@dynatrace-sdk/client-app-settings/cjs/index.js"(exports, module) {
    "use strict";
    var __defProp2 = Object.defineProperty;
    var __getOwnPropDesc2 = Object.getOwnPropertyDescriptor;
    var __getOwnPropNames2 = Object.getOwnPropertyNames;
    var __hasOwnProp2 = Object.prototype.hasOwnProperty;
    var __export = (target, all) => {
      for (var name in all)
        __defProp2(target, name, { get: all[name], enumerable: true });
    };
    var __copyProps2 = (to, from, except, desc) => {
      if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames2(from))
          if (!__hasOwnProp2.call(to, key) && key !== except)
            __defProp2(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc2(from, key)) || desc.enumerable });
      }
      return to;
    };
    var __toCommonJS = (mod) => __copyProps2(__defProp2({}, "__esModule", { value: true }), mod);
    var src_exports = {};
    __export(src_exports, {
      AppSettingsObjectsClient: () => AppSettingsObjectsClient,
      ConstraintViolationParameterLocation: () => ConstraintViolationParameterLocation,
      _AppSettingsErrorDetailsTransformation: () => _AppSettingsErrorDetailsTransformation,
      _AppSettingsErrorEnvelopeTransformation: () => _AppSettingsErrorEnvelopeTransformation,
      _AppSettingsErrorTransformation: () => _AppSettingsErrorTransformation,
      _AppSettingsObjectCreateTransformation: () => _AppSettingsObjectCreateTransformation,
      _AppSettingsObjectResponseTransformation: () => _AppSettingsObjectResponseTransformation,
      _AppSettingsObjectTransformation: () => _AppSettingsObjectTransformation,
      _AppSettingsObjectUpdateTransformation: () => _AppSettingsObjectUpdateTransformation,
      _AppSettingsObjectsListTransformation: () => _AppSettingsObjectsListTransformation,
      _AppSettingsValueTransformation: () => _AppSettingsValueTransformation,
      _ConstraintViolationParameterLocationTransformation: () => _ConstraintViolationParameterLocationTransformation,
      _ConstraintViolationTransformation: () => _ConstraintViolationTransformation,
      _EffectiveAppSettingsValueTransformation: () => _EffectiveAppSettingsValueTransformation,
      _EffectiveAppSettingsValuesListTransformation: () => _EffectiveAppSettingsValuesListTransformation,
      appSettingsObjectsClient: () => appSettingsObjectsClient,
      isApiClientError: () => isApiClientError,
      isAppSettingsErrorEnvelopeError: () => isAppSettingsErrorEnvelopeError,
      isClientRequestError: () => isClientRequestError
    });
    module.exports = __toCommonJS(src_exports);
    var import_http_client = require_cjs2();
    var getGlobalWithDtRuntime = () => typeof globalThis !== "undefined" ? globalThis : window;
    function addGlobalErrorSerializer(serializer) {
      const addGlobalErrorSerializerFunc = getAddGlobalErrorSerializer();
      if (typeof addGlobalErrorSerializerFunc === "function") {
        addGlobalErrorSerializerFunc(serializer);
      } else {
        console.warn("Missing addGlobalErrorSerializer function from sdk-web-runtime.");
      }
    }
    function isGlobalErrorSerializerSupported() {
      return typeof getAddGlobalErrorSerializer() === "function";
    }
    function getAddGlobalErrorSerializer() {
      return getGlobalWithDtRuntime().dtRuntime?.errorHandlers?.addGlobalErrorSerializer;
    }
    var ApiClientError = class extends Error {
      errorType = "JS Error";
      constructor(name, message) {
        super(message);
        this.name = name;
      }
    };
    function isApiClientError(e) {
      return e instanceof ApiClientError;
    }
    var ClientRequestError = class extends ApiClientError {
      body;
      response;
      constructor(name, response, body, message) {
        super(name, message);
        this.errorType = "Http Error";
        this.body = body;
        this.response = response;
      }
    };
    function isClientRequestError(e) {
      return e instanceof ClientRequestError;
    }
    var AppSettingsErrorEnvelopeError = class extends ClientRequestError {
    };
    function isAppSettingsErrorEnvelopeError(e) {
      return e instanceof AppSettingsErrorEnvelopeError;
    }
    var apiClientErrorSerializer = async (error) => {
      if (isClientRequestError(error)) {
        const status = error.response.status;
        const message = error.message;
        return {
          name: error.name,
          status,
          message,
          stack: error.stack,
          type: "Http Error",
          body: error.body
        };
      } else if (isApiClientError(error)) {
        return {
          name: error.name,
          message: error.message,
          stack: error.stack,
          type: "JS Error"
          /* COMMON */
        };
      }
    };
    var errorSerializerAdded = false;
    function registerGlobalErrorSerializer(serializer) {
      if (!errorSerializerAdded && isGlobalErrorSerializerSupported()) {
        errorSerializerAdded = true;
        addGlobalErrorSerializer(serializer);
      }
    }
    var InvalidResponseError = class extends ApiClientError {
      responseBody;
      expectedType;
      nestedError;
      constructor(name, nestedError, body, expectedType, message) {
        super(
          name,
          message ?? `${name}: Response does not match expected datatype${expectedType ? " " + expectedType : ""}: ${nestedError?.toString() ?? "unable to deserialize"}`
        );
        this.nestedError = nestedError;
        this.responseBody = body;
        this.expectedType = expectedType;
      }
    };
    var ConstraintViolationParameterLocation = /* @__PURE__ */ ((ConstraintViolationParameterLocation3) => {
      ConstraintViolationParameterLocation3["Header"] = "HEADER";
      ConstraintViolationParameterLocation3["Path"] = "PATH";
      ConstraintViolationParameterLocation3["PayloadBody"] = "PAYLOAD_BODY";
      ConstraintViolationParameterLocation3["Query"] = "QUERY";
      return ConstraintViolationParameterLocation3;
    })(ConstraintViolationParameterLocation || {});
    var _ConstraintViolationParameterLocationTransformation;
    ((_ConstraintViolationParameterLocationTransformation2) => {
      _ConstraintViolationParameterLocationTransformation2.toJson = (value) => value;
      _ConstraintViolationParameterLocationTransformation2.fromJson = (value) => value;
    })(_ConstraintViolationParameterLocationTransformation || (_ConstraintViolationParameterLocationTransformation = {}));
    var _ConstraintViolationTransformation;
    ((_ConstraintViolationTransformation2) => {
      function fromJson($model) {
        const { path, message, location, parameterLocation } = $model;
        return {
          path,
          message,
          location,
          parameterLocation: parameterLocation !== void 0 && parameterLocation !== null ? _ConstraintViolationParameterLocationTransformation.fromJson(parameterLocation) : void 0
        };
      }
      _ConstraintViolationTransformation2.fromJson = fromJson;
      function toJson($model) {
        const { path, message, location, parameterLocation } = $model;
        return {
          path,
          message,
          location,
          parameterLocation: parameterLocation !== void 0 && parameterLocation !== null ? _ConstraintViolationParameterLocationTransformation.toJson(parameterLocation) : void 0
        };
      }
      _ConstraintViolationTransformation2.toJson = toJson;
    })(_ConstraintViolationTransformation || (_ConstraintViolationTransformation = {}));
    var _AppSettingsErrorDetailsTransformation;
    ((_AppSettingsErrorDetailsTransformation2) => {
      function fromJson($model) {
        const { constraintViolations } = $model;
        return {
          constraintViolations: constraintViolations !== void 0 && constraintViolations !== null ? constraintViolations?.map((innerValue) => _ConstraintViolationTransformation.fromJson(innerValue)) : void 0
        };
      }
      _AppSettingsErrorDetailsTransformation2.fromJson = fromJson;
      function toJson($model) {
        const { constraintViolations } = $model;
        return {
          constraintViolations: constraintViolations !== void 0 && constraintViolations !== null ? constraintViolations?.map((innerValue) => _ConstraintViolationTransformation.toJson(innerValue)) : void 0
        };
      }
      _AppSettingsErrorDetailsTransformation2.toJson = toJson;
    })(_AppSettingsErrorDetailsTransformation || (_AppSettingsErrorDetailsTransformation = {}));
    var _AppSettingsErrorTransformation;
    ((_AppSettingsErrorTransformation2) => {
      function fromJson($model) {
        const { code, message, details } = $model;
        return {
          code,
          message,
          details: details !== void 0 && details !== null ? _AppSettingsErrorDetailsTransformation.fromJson(details) : void 0
        };
      }
      _AppSettingsErrorTransformation2.fromJson = fromJson;
      function toJson($model) {
        const { code, message, details } = $model;
        return {
          code,
          message,
          details: details !== void 0 && details !== null ? _AppSettingsErrorDetailsTransformation.toJson(details) : void 0
        };
      }
      _AppSettingsErrorTransformation2.toJson = toJson;
    })(_AppSettingsErrorTransformation || (_AppSettingsErrorTransformation = {}));
    var _AppSettingsErrorEnvelopeTransformation;
    ((_AppSettingsErrorEnvelopeTransformation2) => {
      function fromJson($model) {
        const { error } = $model;
        return {
          error: _AppSettingsErrorTransformation.fromJson(error)
        };
      }
      _AppSettingsErrorEnvelopeTransformation2.fromJson = fromJson;
      function toJson($model) {
        const { error } = $model;
        return {
          error: _AppSettingsErrorTransformation.toJson(error)
        };
      }
      _AppSettingsErrorEnvelopeTransformation2.toJson = toJson;
      function fromFormData(formData) {
        const formDataEntries = Object.fromEntries(formData.map((data) => [data.name, data.value]));
        return {
          error: _AppSettingsErrorTransformation.fromJson(JSON.parse(formDataEntries["error"]))
        };
      }
      _AppSettingsErrorEnvelopeTransformation2.fromFormData = fromFormData;
      function toFormData($model) {
        const json = toJson($model);
        const body = [{ name: "error", type: "json", value: json["error"] }];
        return body;
      }
      _AppSettingsErrorEnvelopeTransformation2.toFormData = toFormData;
    })(_AppSettingsErrorEnvelopeTransformation || (_AppSettingsErrorEnvelopeTransformation = {}));
    var _AppSettingsValueTransformation;
    ((_AppSettingsValueTransformation2) => {
      function fromJson(model) {
        return JSON.parse(JSON.stringify(model));
      }
      _AppSettingsValueTransformation2.fromJson = fromJson;
      function toJson(model) {
        return JSON.parse(JSON.stringify(model));
      }
      _AppSettingsValueTransformation2.toJson = toJson;
    })(_AppSettingsValueTransformation || (_AppSettingsValueTransformation = {}));
    var _AppSettingsObjectTransformation;
    ((_AppSettingsObjectTransformation2) => {
      function fromJson($model) {
        const { objectId, summary, searchSummary, version, schemaId, schemaVersion, value } = $model;
        return {
          objectId,
          summary,
          searchSummary,
          version,
          schemaId,
          schemaVersion,
          value: value !== void 0 && value !== null ? _AppSettingsValueTransformation.fromJson(value) : void 0
        };
      }
      _AppSettingsObjectTransformation2.fromJson = fromJson;
      function toJson($model) {
        const { objectId, summary, searchSummary, version, schemaId, schemaVersion, value } = $model;
        return {
          objectId,
          summary,
          searchSummary,
          version,
          schemaId,
          schemaVersion,
          value: value !== void 0 && value !== null ? _AppSettingsValueTransformation.toJson(value) : void 0
        };
      }
      _AppSettingsObjectTransformation2.toJson = toJson;
    })(_AppSettingsObjectTransformation || (_AppSettingsObjectTransformation = {}));
    var _AppSettingsObjectCreateTransformation;
    ((_AppSettingsObjectCreateTransformation2) => {
      function fromJson($model) {
        const { schemaId, schemaVersion, value, insertAfter } = $model;
        return {
          schemaId,
          schemaVersion,
          value: _AppSettingsValueTransformation.fromJson(value),
          insertAfter
        };
      }
      _AppSettingsObjectCreateTransformation2.fromJson = fromJson;
      function toJson($model) {
        const { schemaId, schemaVersion, value, insertAfter } = $model;
        return {
          schemaId,
          schemaVersion,
          value: _AppSettingsValueTransformation.toJson(value),
          insertAfter
        };
      }
      _AppSettingsObjectCreateTransformation2.toJson = toJson;
    })(_AppSettingsObjectCreateTransformation || (_AppSettingsObjectCreateTransformation = {}));
    var _AppSettingsObjectResponseTransformation;
    ((_AppSettingsObjectResponseTransformation2) => {
      function fromJson($model) {
        const { objectId, version } = $model;
        return {
          objectId,
          version
        };
      }
      _AppSettingsObjectResponseTransformation2.fromJson = fromJson;
      function toJson($model) {
        const { objectId, version } = $model;
        return {
          objectId,
          version
        };
      }
      _AppSettingsObjectResponseTransformation2.toJson = toJson;
    })(_AppSettingsObjectResponseTransformation || (_AppSettingsObjectResponseTransformation = {}));
    var _AppSettingsObjectUpdateTransformation;
    ((_AppSettingsObjectUpdateTransformation2) => {
      function fromJson($model) {
        const { schemaVersion, value, insertAfter, insertBefore } = $model;
        return {
          schemaVersion,
          value: _AppSettingsValueTransformation.fromJson(value),
          insertAfter,
          insertBefore
        };
      }
      _AppSettingsObjectUpdateTransformation2.fromJson = fromJson;
      function toJson($model) {
        const { schemaVersion, value, insertAfter, insertBefore } = $model;
        return {
          schemaVersion,
          value: _AppSettingsValueTransformation.toJson(value),
          insertAfter,
          insertBefore
        };
      }
      _AppSettingsObjectUpdateTransformation2.toJson = toJson;
    })(_AppSettingsObjectUpdateTransformation || (_AppSettingsObjectUpdateTransformation = {}));
    var _AppSettingsObjectsListTransformation;
    ((_AppSettingsObjectsListTransformation2) => {
      function fromJson($model) {
        const { totalCount, pageSize, nextPageKey, items } = $model;
        return {
          totalCount,
          pageSize,
          nextPageKey,
          items: items?.map((innerValue) => _AppSettingsObjectTransformation.fromJson(innerValue))
        };
      }
      _AppSettingsObjectsListTransformation2.fromJson = fromJson;
      function toJson($model) {
        const { totalCount, pageSize, nextPageKey, items } = $model;
        return {
          totalCount,
          pageSize,
          nextPageKey,
          items: items?.map((innerValue) => _AppSettingsObjectTransformation.toJson(innerValue))
        };
      }
      _AppSettingsObjectsListTransformation2.toJson = toJson;
    })(_AppSettingsObjectsListTransformation || (_AppSettingsObjectsListTransformation = {}));
    var _EffectiveAppSettingsValueTransformation;
    ((_EffectiveAppSettingsValueTransformation2) => {
      function fromJson($model) {
        const { summary, searchSummary, schemaId, schemaVersion, value } = $model;
        return {
          summary,
          searchSummary,
          schemaId,
          schemaVersion,
          value: value !== void 0 && value !== null ? _AppSettingsValueTransformation.fromJson(value) : void 0
        };
      }
      _EffectiveAppSettingsValueTransformation2.fromJson = fromJson;
      function toJson($model) {
        const { summary, searchSummary, schemaId, schemaVersion, value } = $model;
        return {
          summary,
          searchSummary,
          schemaId,
          schemaVersion,
          value: value !== void 0 && value !== null ? _AppSettingsValueTransformation.toJson(value) : void 0
        };
      }
      _EffectiveAppSettingsValueTransformation2.toJson = toJson;
    })(_EffectiveAppSettingsValueTransformation || (_EffectiveAppSettingsValueTransformation = {}));
    var _EffectiveAppSettingsValuesListTransformation;
    ((_EffectiveAppSettingsValuesListTransformation2) => {
      function fromJson($model) {
        const { totalCount, pageSize, nextPageKey, items } = $model;
        return {
          totalCount,
          pageSize,
          nextPageKey,
          items: items?.map((innerValue) => _EffectiveAppSettingsValueTransformation.fromJson(innerValue))
        };
      }
      _EffectiveAppSettingsValuesListTransformation2.fromJson = fromJson;
      function toJson($model) {
        const { totalCount, pageSize, nextPageKey, items } = $model;
        return {
          totalCount,
          pageSize,
          nextPageKey,
          items: items?.map((innerValue) => _EffectiveAppSettingsValueTransformation.toJson(innerValue))
        };
      }
      _EffectiveAppSettingsValuesListTransformation2.toJson = toJson;
    })(_EffectiveAppSettingsValuesListTransformation || (_EffectiveAppSettingsValuesListTransformation = {}));
    var encodeQueryParam = (key, value) => {
      const encodedKey = encodeURIComponent(key);
      return `${encodedKey}=${encodeURIComponent(typeof value === "number" ? value : String(value))}`;
    };
    var addArrayQueryParam = (query, key) => {
      const arrayValue = query[key];
      return arrayValue.map((value) => encodeQueryParam(key, value)).join("&");
    };
    var addQueryParam = (query, key) => encodeQueryParam(key, query[key]);
    var toQueryString = (rawQuery) => {
      const query = rawQuery || {};
      const keys = Object.keys(query).filter((key) => typeof query[key] !== "undefined");
      const queryString = keys.map((key) => Array.isArray(query[key]) ? addArrayQueryParam(query, key) : addQueryParam(query, key)).join("&");
      return queryString ? `?${queryString}` : "";
    };
    var AppSettingsObjectsClient = class {
      httpClient;
      constructor(httpClientImplementation) {
        this.httpClient = httpClientImplementation;
        registerGlobalErrorSerializer(apiClientErrorSerializer);
      }
      async getAppSettingsObjectByObjectId(config) {
        const response = await this.httpClient.send({
          url: `/platform/app-settings/v1/objects/${config.objectId}`,
          method: "GET",
          headers: {
            Accept: "application/json; charset=utf-8, application/json"
          },
          abortSignal: config.abortSignal,
          statusValidator: (status) => {
            if (200 <= status && status < 300) {
              return true;
            }
            return [403, 404].includes(status);
          }
        });
        switch (response.status) {
          case 403: {
            const responseValue = await response.body("json");
            try {
              const errorBody = _AppSettingsErrorEnvelopeTransformation.fromJson(responseValue);
              throw new AppSettingsErrorEnvelopeError("403", response, errorBody, "Failed. Forbidden.");
            } catch (err) {
              if (err instanceof AppSettingsErrorEnvelopeError) {
                throw err;
              }
              throw new InvalidResponseError(
                `AppSettingsObjectsClient.getAppSettingsObjectByObjectId:403`,
                err,
                responseValue,
                "AppSettingsErrorEnvelope",
                void 0
              );
            }
          }
          case 404: {
            const responseValue = await response.body("json");
            try {
              const errorBody = _AppSettingsErrorEnvelopeTransformation.fromJson(responseValue);
              throw new AppSettingsErrorEnvelopeError(
                "404",
                response,
                errorBody,
                "No object available for the given objectId"
              );
            } catch (err) {
              if (err instanceof AppSettingsErrorEnvelopeError) {
                throw err;
              }
              throw new InvalidResponseError(
                `AppSettingsObjectsClient.getAppSettingsObjectByObjectId:404`,
                err,
                responseValue,
                "AppSettingsErrorEnvelope",
                void 0
              );
            }
          }
          case 200: {
            const responseValue = await response.body("json");
            try {
              return _AppSettingsObjectTransformation.fromJson(responseValue);
            } catch (err) {
              throw new InvalidResponseError(
                `AppSettingsObjectsClient.getAppSettingsObjectByObjectId:${response.status}`,
                err,
                responseValue,
                void 0,
                void 0
              );
            }
          }
          default: {
            const responseValue = await response.body("text").catch(() => "");
            throw new ClientRequestError(
              `${response.status}`,
              response,
              responseValue,
              `Unexpected api response: code=${response.status} body="${responseValue}"`
            );
          }
        }
      }
      async putAppSettingsObjectByObjectId(config) {
        if (!config) {
          throw new ApiClientError("API client error", "API client call is missing mandatory config parameter");
        }
        const encodedBody = _AppSettingsObjectUpdateTransformation.toJson(config.body);
        const query = toQueryString({ "optimistic-locking-version": config.optimisticLockingVersion });
        const response = await this.httpClient.send({
          url: `/platform/app-settings/v1/objects/${config.objectId}${query}`,
          method: "PUT",
          requestBodyType: "json",
          body: encodedBody,
          headers: {
            "Content-Type": "application/json; charset=utf-8"
          },
          abortSignal: config.abortSignal,
          statusValidator: (status) => {
            if (200 <= status && status < 300) {
              return true;
            }
            return [400, 403, 404, 409].includes(status);
          }
        });
        switch (response.status) {
          case 400: {
            const responseValue = await response.body("json");
            try {
              const errorBody = _AppSettingsErrorEnvelopeTransformation.fromJson(responseValue);
              throw new AppSettingsErrorEnvelopeError("400", response, errorBody, "Failed. Schema validation failed.");
            } catch (err) {
              if (err instanceof AppSettingsErrorEnvelopeError) {
                throw err;
              }
              throw new InvalidResponseError(
                `AppSettingsObjectsClient.putAppSettingsObjectByObjectId:400`,
                err,
                responseValue,
                "AppSettingsErrorEnvelope",
                void 0
              );
            }
          }
          case 403: {
            const responseValue = await response.body("json");
            try {
              const errorBody = _AppSettingsErrorEnvelopeTransformation.fromJson(responseValue);
              throw new AppSettingsErrorEnvelopeError("403", response, errorBody, "Failed. Forbidden.");
            } catch (err) {
              if (err instanceof AppSettingsErrorEnvelopeError) {
                throw err;
              }
              throw new InvalidResponseError(
                `AppSettingsObjectsClient.putAppSettingsObjectByObjectId:403`,
                err,
                responseValue,
                "AppSettingsErrorEnvelope",
                void 0
              );
            }
          }
          case 404: {
            const responseValue = await response.body("json");
            try {
              const errorBody = _AppSettingsErrorEnvelopeTransformation.fromJson(responseValue);
              throw new AppSettingsErrorEnvelopeError(
                "404",
                response,
                errorBody,
                "Failed. The requested resource doesn't exist."
              );
            } catch (err) {
              if (err instanceof AppSettingsErrorEnvelopeError) {
                throw err;
              }
              throw new InvalidResponseError(
                `AppSettingsObjectsClient.putAppSettingsObjectByObjectId:404`,
                err,
                responseValue,
                "AppSettingsErrorEnvelope",
                void 0
              );
            }
          }
          case 409: {
            const responseValue = await response.body("json");
            try {
              const errorBody = _AppSettingsErrorEnvelopeTransformation.fromJson(responseValue);
              throw new AppSettingsErrorEnvelopeError("409", response, errorBody, "Failed. Conflicting resource.");
            } catch (err) {
              if (err instanceof AppSettingsErrorEnvelopeError) {
                throw err;
              }
              throw new InvalidResponseError(
                `AppSettingsObjectsClient.putAppSettingsObjectByObjectId:409`,
                err,
                responseValue,
                "AppSettingsErrorEnvelope",
                void 0
              );
            }
          }
          case 200: {
            return;
          }
          default: {
            const responseValue = await response.body("text").catch(() => "");
            throw new ClientRequestError(
              `${response.status}`,
              response,
              responseValue,
              `Unexpected api response: code=${response.status} body="${responseValue}"`
            );
          }
        }
      }
      async deleteAppSettingsObjectByObjectId(config) {
        if (!config) {
          throw new ApiClientError("API client error", "API client call is missing mandatory config parameter");
        }
        const query = toQueryString({ "optimistic-locking-version": config.optimisticLockingVersion });
        const response = await this.httpClient.send({
          url: `/platform/app-settings/v1/objects/${config.objectId}${query}`,
          method: "DELETE",
          abortSignal: config.abortSignal,
          statusValidator: (status) => {
            if (200 <= status && status < 300) {
              return true;
            }
            return [400, 403, 404, 409].includes(status);
          }
        });
        switch (response.status) {
          case 400: {
            const responseValue = await response.body("json");
            try {
              const errorBody = _AppSettingsErrorEnvelopeTransformation.fromJson(responseValue);
              throw new AppSettingsErrorEnvelopeError("400", response, errorBody, "Failed. Schema validation failed.");
            } catch (err) {
              if (err instanceof AppSettingsErrorEnvelopeError) {
                throw err;
              }
              throw new InvalidResponseError(
                `AppSettingsObjectsClient.deleteAppSettingsObjectByObjectId:400`,
                err,
                responseValue,
                "AppSettingsErrorEnvelope",
                void 0
              );
            }
          }
          case 403: {
            const responseValue = await response.body("json");
            try {
              const errorBody = _AppSettingsErrorEnvelopeTransformation.fromJson(responseValue);
              throw new AppSettingsErrorEnvelopeError("403", response, errorBody, "Failed. Forbidden.");
            } catch (err) {
              if (err instanceof AppSettingsErrorEnvelopeError) {
                throw err;
              }
              throw new InvalidResponseError(
                `AppSettingsObjectsClient.deleteAppSettingsObjectByObjectId:403`,
                err,
                responseValue,
                "AppSettingsErrorEnvelope",
                void 0
              );
            }
          }
          case 404: {
            const responseValue = await response.body("json");
            try {
              const errorBody = _AppSettingsErrorEnvelopeTransformation.fromJson(responseValue);
              throw new AppSettingsErrorEnvelopeError(
                "404",
                response,
                errorBody,
                "Failed. The requested resource doesn't exist."
              );
            } catch (err) {
              if (err instanceof AppSettingsErrorEnvelopeError) {
                throw err;
              }
              throw new InvalidResponseError(
                `AppSettingsObjectsClient.deleteAppSettingsObjectByObjectId:404`,
                err,
                responseValue,
                "AppSettingsErrorEnvelope",
                void 0
              );
            }
          }
          case 409: {
            const responseValue = await response.body("json");
            try {
              const errorBody = _AppSettingsErrorEnvelopeTransformation.fromJson(responseValue);
              throw new AppSettingsErrorEnvelopeError("409", response, errorBody, "Failed. Conflicting resource.");
            } catch (err) {
              if (err instanceof AppSettingsErrorEnvelopeError) {
                throw err;
              }
              throw new InvalidResponseError(
                `AppSettingsObjectsClient.deleteAppSettingsObjectByObjectId:409`,
                err,
                responseValue,
                "AppSettingsErrorEnvelope",
                void 0
              );
            }
          }
          case 204: {
            return;
          }
          default: {
            const responseValue = await response.body("text").catch(() => "");
            throw new ClientRequestError(
              `${response.status}`,
              response,
              responseValue,
              `Unexpected api response: code=${response.status} body="${responseValue}"`
            );
          }
        }
      }
      async getAppSettingsObjects(config = {}) {
        if (!config) {
          throw new ApiClientError("API client error", "API client call is missing mandatory config parameter");
        }
        const query = toQueryString({
          "schema-ids": config.schemaIds,
          "add-fields": config.addFields,
          "page-key": config.pageKey,
          "page-size": config.pageSize
        });
        const response = await this.httpClient.send({
          url: `/platform/app-settings/v1/objects${query}`,
          method: "GET",
          headers: {
            Accept: "application/json; charset=utf-8, application/json"
          },
          abortSignal: config.abortSignal,
          statusValidator: (status) => {
            if (200 <= status && status < 300) {
              return true;
            }
            return [403, 404].includes(status);
          }
        });
        switch (response.status) {
          case 403: {
            const responseValue = await response.body("json");
            try {
              const errorBody = _AppSettingsErrorEnvelopeTransformation.fromJson(responseValue);
              throw new AppSettingsErrorEnvelopeError("403", response, errorBody, "Failed. Forbidden.");
            } catch (err) {
              if (err instanceof AppSettingsErrorEnvelopeError) {
                throw err;
              }
              throw new InvalidResponseError(
                `AppSettingsObjectsClient.getAppSettingsObjects:403`,
                err,
                responseValue,
                "AppSettingsErrorEnvelope",
                void 0
              );
            }
          }
          case 404: {
            const responseValue = await response.body("json");
            try {
              const errorBody = _AppSettingsErrorEnvelopeTransformation.fromJson(responseValue);
              throw new AppSettingsErrorEnvelopeError(
                "404",
                response,
                errorBody,
                "Failed. The specified schema was not found."
              );
            } catch (err) {
              if (err instanceof AppSettingsErrorEnvelopeError) {
                throw err;
              }
              throw new InvalidResponseError(
                `AppSettingsObjectsClient.getAppSettingsObjects:404`,
                err,
                responseValue,
                "AppSettingsErrorEnvelope",
                void 0
              );
            }
          }
          case 200: {
            const responseValue = await response.body("json");
            try {
              return _AppSettingsObjectsListTransformation.fromJson(responseValue);
            } catch (err) {
              throw new InvalidResponseError(
                `AppSettingsObjectsClient.getAppSettingsObjects:${response.status}`,
                err,
                responseValue,
                void 0,
                void 0
              );
            }
          }
          default: {
            const responseValue = await response.body("text").catch(() => "");
            throw new ClientRequestError(
              `${response.status}`,
              response,
              responseValue,
              `Unexpected api response: code=${response.status} body="${responseValue}"`
            );
          }
        }
      }
      async postAppSettingsObject(config) {
        if (!config) {
          throw new ApiClientError("API client error", "API client call is missing mandatory config parameter");
        }
        const encodedBody = _AppSettingsObjectCreateTransformation.toJson(config.body);
        const query = toQueryString({ "validate-only": config.validateOnly });
        const response = await this.httpClient.send({
          url: `/platform/app-settings/v1/objects${query}`,
          method: "POST",
          requestBodyType: "json",
          body: encodedBody,
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            Accept: "application/json; charset=utf-8, application/json"
          },
          abortSignal: config.abortSignal,
          statusValidator: (status) => {
            if (200 <= status && status < 300) {
              return true;
            }
            return [400, 403, 404, 409].includes(status);
          }
        });
        switch (response.status) {
          case 400: {
            const responseValue = await response.body("json");
            try {
              const errorBody = _AppSettingsErrorEnvelopeTransformation.fromJson(responseValue);
              throw new AppSettingsErrorEnvelopeError("400", response, errorBody, "Failed. Schema validation failed.");
            } catch (err) {
              if (err instanceof AppSettingsErrorEnvelopeError) {
                throw err;
              }
              throw new InvalidResponseError(
                `AppSettingsObjectsClient.postAppSettingsObject:400`,
                err,
                responseValue,
                "AppSettingsErrorEnvelope",
                void 0
              );
            }
          }
          case 403: {
            const responseValue = await response.body("json");
            try {
              const errorBody = _AppSettingsErrorEnvelopeTransformation.fromJson(responseValue);
              throw new AppSettingsErrorEnvelopeError("403", response, errorBody, "Failed. Forbidden.");
            } catch (err) {
              if (err instanceof AppSettingsErrorEnvelopeError) {
                throw err;
              }
              throw new InvalidResponseError(
                `AppSettingsObjectsClient.postAppSettingsObject:403`,
                err,
                responseValue,
                "AppSettingsErrorEnvelope",
                void 0
              );
            }
          }
          case 404: {
            const responseValue = await response.body("json");
            try {
              const errorBody = _AppSettingsErrorEnvelopeTransformation.fromJson(responseValue);
              throw new AppSettingsErrorEnvelopeError(
                "404",
                response,
                errorBody,
                "Failed. The requested resource doesn't exist."
              );
            } catch (err) {
              if (err instanceof AppSettingsErrorEnvelopeError) {
                throw err;
              }
              throw new InvalidResponseError(
                `AppSettingsObjectsClient.postAppSettingsObject:404`,
                err,
                responseValue,
                "AppSettingsErrorEnvelope",
                void 0
              );
            }
          }
          case 409: {
            const responseValue = await response.body("json");
            try {
              const errorBody = _AppSettingsErrorEnvelopeTransformation.fromJson(responseValue);
              throw new AppSettingsErrorEnvelopeError("409", response, errorBody, "Failed. Conflicting resource.");
            } catch (err) {
              if (err instanceof AppSettingsErrorEnvelopeError) {
                throw err;
              }
              throw new InvalidResponseError(
                `AppSettingsObjectsClient.postAppSettingsObject:409`,
                err,
                responseValue,
                "AppSettingsErrorEnvelope",
                void 0
              );
            }
          }
          case 200: {
            return;
          }
          case 201: {
            const responseValue = await response.body("json");
            try {
              return _AppSettingsObjectResponseTransformation.fromJson(responseValue);
            } catch (err) {
              throw new InvalidResponseError(
                `AppSettingsObjectsClient.postAppSettingsObject:${response.status}`,
                err,
                responseValue,
                void 0,
                void 0
              );
            }
          }
          default: {
            const responseValue = await response.body("text").catch(() => "");
            throw new ClientRequestError(
              `${response.status}`,
              response,
              responseValue,
              `Unexpected api response: code=${response.status} body="${responseValue}"`
            );
          }
        }
      }
      async getEffectiveAppSettingsValues(config = {}) {
        if (!config) {
          throw new ApiClientError("API client error", "API client call is missing mandatory config parameter");
        }
        const query = toQueryString({
          "schema-ids": config.schemaIds,
          "add-fields": config.addFields,
          "page-key": config.pageKey,
          "page-size": config.pageSize
        });
        const response = await this.httpClient.send({
          url: `/platform/app-settings/v1/effective-values${query}`,
          method: "GET",
          headers: {
            Accept: "application/json; charset=utf-8, application/json"
          },
          abortSignal: config.abortSignal,
          statusValidator: (status) => {
            if (200 <= status && status < 300) {
              return true;
            }
            return [404].includes(status);
          }
        });
        switch (response.status) {
          case 404: {
            const responseValue = await response.body("json");
            try {
              const errorBody = _AppSettingsErrorEnvelopeTransformation.fromJson(responseValue);
              throw new AppSettingsErrorEnvelopeError(
                "404",
                response,
                errorBody,
                "Failed. The specified schema is not found."
              );
            } catch (err) {
              if (err instanceof AppSettingsErrorEnvelopeError) {
                throw err;
              }
              throw new InvalidResponseError(
                `AppSettingsObjectsClient.getEffectiveAppSettingsValues:404`,
                err,
                responseValue,
                "AppSettingsErrorEnvelope",
                void 0
              );
            }
          }
          case 200: {
            const responseValue = await response.body("json");
            try {
              return _EffectiveAppSettingsValuesListTransformation.fromJson(responseValue);
            } catch (err) {
              throw new InvalidResponseError(
                `AppSettingsObjectsClient.getEffectiveAppSettingsValues:${response.status}`,
                err,
                responseValue,
                void 0,
                void 0
              );
            }
          }
          default: {
            const responseValue = await response.body("text").catch(() => "");
            throw new ClientRequestError(
              `${response.status}`,
              response,
              responseValue,
              `Unexpected api response: code=${response.status} body="${responseValue}"`
            );
          }
        }
      }
    };
    var appSettingsObjectsClient = /* @__PURE__ */ new AppSettingsObjectsClient(import_http_client.httpClient);
  }
});

// node_modules/@dynatrace/sdk-automation-labs/lib/actions/connections.js
var require_connections = __commonJS({
  "node_modules/@dynatrace/sdk-automation-labs/lib/actions/connections.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.BaseConnection = exports.getConnection = void 0;
    var client_app_settings_1 = require_cjs3();
    async function getConnection2(connectionId, builder) {
      const connection = await client_app_settings_1.appSettingsObjectsClient.getAppSettingsObjectByObjectId({ objectId: connectionId });
      return builder(connection.value);
    }
    exports.getConnection = getConnection2;
    var BaseConnection2 = class {
    };
    exports.BaseConnection = BaseConnection2;
  }
});

// node_modules/@dynatrace/sdk-automation-labs/lib/actions/index.js
var require_actions2 = __commonJS({
  "node_modules/@dynatrace/sdk-automation-labs/lib/actions/index.js"(exports) {
    "use strict";
    var __createBinding = exports && exports.__createBinding || (Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    });
    var __exportStar = exports && exports.__exportStar || function(m, exports2) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports2, p))
          __createBinding(exports2, m, p);
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    __exportStar(require_action_config_types(), exports);
    __exportStar(require_actions(), exports);
    __exportStar(require_connections(), exports);
  }
});

// api/build.ts
var import_actions2 = __toESM(require_actions2());

// src/shared/connections/jenkins-connection.ts
var import_actions = __toESM(require_actions2());
var REQUIRED_ATTRIBUTES = ["url", "user", "token"];
var JenkinsConnection = class extends import_actions.BaseConnection {
  baseUrl;
  authHeaders;
  initialize(rawPayload) {
    (0, import_actions.validateRequiredAttributes)(rawPayload, REQUIRED_ATTRIBUTES);
    const { url, token, user } = rawPayload;
    this.baseUrl = new URL(url);
    const basicAuthHeaderValue = "Basic " + btoa(user + ":" + token);
    this.authHeaders = new Headers({
      Authorization: basicAuthHeaderValue
    });
    return this;
  }
};
var initializeJenkinsConnection = async (connectionId) => (0, import_actions.getConnection)(connectionId, (rawConnectionPayload) => {
  return new JenkinsConnection().initialize(rawConnectionPayload);
});

// src/shared/util/jenkins-api.ts
var sanitizeJenkinsJobUrl = (rawUrl) => {
  let pathName = "";
  try {
    pathName = new URL(rawUrl).pathname;
  } catch (err) {
    pathName = rawUrl;
  }
  if (pathName.startsWith("/"))
    pathName = pathName.substring(1);
  if (pathName.endsWith("/"))
    pathName = pathName.substring(0, pathName.length - 1);
  return pathName;
};
var parseBuildUrl = (buildJob, baseUrl) => {
  const buildJobPath = sanitizeJenkinsJobUrl(buildJob) + "/build";
  const buildUrl = new URL(buildJobPath, baseUrl);
  buildUrl.searchParams.append("delay", "0sec");
  return buildUrl;
};
var parseBuildWithParametersUrl = (buildJob, baseUrl) => {
  const buildJobPath = sanitizeJenkinsJobUrl(buildJob) + "/buildWithParameters";
  const buildUrl = new URL(buildJobPath, baseUrl);
  buildUrl.searchParams.append("delay", "0sec");
  return buildUrl;
};
var parseQueueItemNumber = (url) => {
  try {
    const rawQueueItemNumber = url.pathname.replace("/queue/item/", "").split("/")[0];
    return parseInt(rawQueueItemNumber);
  } catch (error) {
    return void 0;
  }
};
var buildJenkinsJob = async (logger, baseUrl, authHeaders, buildJob) => {
  const buildUrl = parseBuildUrl(buildJob, baseUrl);
  const headers = authHeaders;
  headers.append("Content-Type", "application/x-www-form-urlencoded");
  const resp = await fetch(buildUrl, {
    method: "POST",
    headers
  });
  if (!resp.ok) {
    logger.error(await resp.text());
    throw new Error(`${resp.statusText}`);
  }
  return resp;
};
var buildJenkinsJobWithParameters = async (logger, baseUrl, authHeaders, buildJob, parameters) => {
  const buildUrl = parseBuildWithParametersUrl(buildJob, baseUrl);
  for (const { name, value } of parameters) {
    if (value === null) {
      continue;
    }
    if (typeof value === "boolean") {
      buildUrl.searchParams.append(name, value ? "true" : "false");
      continue;
    }
    buildUrl.searchParams.append(name, value);
  }
  const headers = authHeaders;
  const resp = await fetch(buildUrl, {
    method: "POST",
    headers
  });
  if (!resp.ok) {
    logger.error(await resp.text());
    throw new Error(`${resp.statusText}`);
  }
  return resp;
};

// api/build.ts
var REQUIRED_ATTRIBUTES2 = ["connectionId", "buildJob", "buildParams"];
var Build = class extends import_actions2.BaseAction {
  buildJob = { type: "STRING", value: void 0 };
  buildParams = [];
  connectionId = "";
  async initialize(rawPayload) {
    (0, import_actions2.validateRequiredAttributes)(rawPayload, REQUIRED_ATTRIBUTES2);
    const { connectionId, buildJob, buildParams } = rawPayload;
    this.buildJob = buildJob;
    this.buildParams = buildParams;
    this.connectionId = connectionId;
  }
  async run() {
    if (!this.buildJob.value) {
      throw new Error("undefined build job");
    }
    const { baseUrl, authHeaders } = await initializeJenkinsConnection(this.connectionId);
    const isBuildWithParameters = this.buildParams.length > 0;
    const rawResp = isBuildWithParameters ? await buildJenkinsJobWithParameters(this.logger, baseUrl, authHeaders, this.buildJob.value, this.buildParams) : await buildJenkinsJob(this.logger, baseUrl, authHeaders, this.buildJob.value);
    const locationHeaderValue = rawResp.headers.get("Location");
    if (!locationHeaderValue) {
      return {
        queueItemNumber: void 0
      };
    }
    const locationUrl = new URL(locationHeaderValue);
    return {
      queueItemNumber: parseQueueItemNumber(locationUrl)
    };
  }
};
async function build_default(payload = void 0) {
  return new Build().runAction(payload);
}
export {
  Build,
  REQUIRED_ATTRIBUTES2 as REQUIRED_ATTRIBUTES,
  build_default as default
};
/*! Bundled license information:

@dynatrace-sdk/error-handlers/cjs/index.js:
  (**
   * @license
   * Copyright 2023 Dynatrace LLC
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@dynatrace-sdk/http-client/cjs/index.js:
  (**
   * @license
   * Copyright 2023 Dynatrace LLC
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)

@dynatrace-sdk/client-app-settings/cjs/index.js:
  (**
   * @license
   * Copyright 2023 Dynatrace LLC
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
*/
